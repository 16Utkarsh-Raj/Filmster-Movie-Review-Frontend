import React from 'react'

export default function Movies() {
  return (
    <div>Movies</div>
  )
}
