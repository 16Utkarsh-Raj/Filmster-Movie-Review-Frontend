import React from 'react'

export default function Actors() {
  return (
    <div>Actors</div>
  )
}
