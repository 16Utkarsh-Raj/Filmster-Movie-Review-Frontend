import React from "react";

import NotVerified from "./user/NotVerified";

export default function Home() {
  return <NotVerified/>
  
}
