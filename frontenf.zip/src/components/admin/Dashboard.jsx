import React from 'react'
import MovieUpload from './MovieUpload'

export default function Dashboard() {
  return (
    <MovieUpload/>
  )
}
